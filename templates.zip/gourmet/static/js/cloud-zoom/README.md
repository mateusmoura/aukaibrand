This is a fork of Version 1.0.2 of Professorclouds cloud zoom.
===============================================================

Formerly found here: http://www.professorcloud.com/mainsite/cloud-zoom.htm

License: MIT

Changes since the fork:

* Since version 1.0.2.3 compatible with jquery 1.9.x +
* You can specify the transparentImage for the mousetrap
* You can disable the creation of the wrapper div
* The wrapper div styles are moved to the css file
* The wrapper div has no longer an id, but a css class name instead (cloud-zoom-wrap)
